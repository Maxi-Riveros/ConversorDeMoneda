package com.example.currencyconverter;

public class RateResponse {
    private double conversion_rate;

    public double getConversionRate() {
        return conversion_rate;
    }

    public void setConversionRate(double conversion_rate) {
        this.conversion_rate = conversion_rate;
    }
}
